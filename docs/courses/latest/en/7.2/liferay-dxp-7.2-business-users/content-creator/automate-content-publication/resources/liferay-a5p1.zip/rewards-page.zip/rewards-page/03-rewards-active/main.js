const content = fragmentElement.querySelector('.03-rewards-active');
