const content = fragmentElement.querySelector('.02-join-now');
