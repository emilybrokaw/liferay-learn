const content = fragmentElement.querySelector('.01-join-rewards');
